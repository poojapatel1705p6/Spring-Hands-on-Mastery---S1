package com.example.demo;

public class Battery extends Product

{
    private int Rechargeable;

	public int getRechargeable() {
		return Rechargeable;
	}

	public void setRechargeable(int rechargeable) {
		Rechargeable = rechargeable;
	}

	@Override
	public String toString() {
		return "Battery [Rechargeable=" + Rechargeable + "]";
	}

	}

