package com.example.demo;

public class Disc extends Product {
	private String Capacity;

	public String getCapacity() {
		return Capacity;
	}

	public void setCapacity(String capacity) {
		Capacity = capacity;
	}

	@Override
	public String toString() {
		return "Disc [Capacity=" + Capacity + "]";
	}

}
