package com.mphasis.shopping3;

public class Product {

	  private double Price;	   
	   private double discount;
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	   
}
